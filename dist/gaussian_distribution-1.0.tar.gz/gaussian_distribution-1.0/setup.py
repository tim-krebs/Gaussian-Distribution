from setuptools import setup

setup(name='gaussian_distribution',
      version='1.0',
      description='Gaussian and Binomnal distribution',
      packages=['gaussian_distribution'],
      author='Tim Krebs',
      author_email='timkrebs9@gmail.com',
      zip_safe=False)